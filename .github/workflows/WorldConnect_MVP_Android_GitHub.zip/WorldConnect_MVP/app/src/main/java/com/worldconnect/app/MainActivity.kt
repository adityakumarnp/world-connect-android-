package com.worldconnect.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp

data class Post(val id: Int, val author: String, val text: String, val privacy: String = "Public", val likes: Int = 0, val liked: Boolean = false, val comments: List<String> = emptyList())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var page by remember { mutableStateOf("Welcome") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("World Connect User") }
    var bio by remember { mutableStateOf("Sharing positivity with the world 🌍") }
    var country by remember { mutableStateOf("Nepal") }
    var language by remember { mutableStateOf("English") }
    var draft by remember { mutableStateOf("") }
    var privacy by remember { mutableStateOf("Public") }
    var commentDraft by remember { mutableStateOf("") }
    var commentId by remember { mutableIntStateOf(-1) }
    var follows by remember { mutableStateOf(setOf<String>()) }
    var messages by remember { mutableStateOf(listOf("World Connect: Welcome to demo chat.")) }
    var message by remember { mutableStateOf("") }
    var posts by remember {
        mutableStateOf(listOf(
            Post(1, "Sunny", "Excellence is not an act; it is a habit. Keep giving your best! ✨"),
            Post(2, "Maya", "A small positive thought can change your whole day. 🌻"),
            Post(3, "World Connect", "Different countries, different languages, one connected world. 🌍")
        ))
    }
    val countries = listOf("Nepal", "India", "Saudi Arabia", "United Arab Emirates", "United States", "United Kingdom", "Canada", "Australia", "Bangladesh", "Other")
    val languages = listOf("English", "Hindi", "Nepali", "Arabic", "Spanish", "French", "Portuguese", "Bengali", "Urdu", "Chinese")

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF176B87))) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("🌍 World Connect") }, actions = { if (page !in listOf("Welcome", "Login", "Register")) IconButton(onClick = { page = "Settings" }) { Icon(Icons.Default.Settings, "Settings") } }) },
            bottomBar = {
                if (page in listOf("Feed", "Create", "People", "Chat", "Profile", "Settings")) {
                    NavigationBar {
                        listOf("Feed" to Icons.Default.Home, "Create" to Icons.Default.AddCircle, "People" to Icons.Default.People, "Chat" to Icons.Default.Chat, "Profile" to Icons.Default.Person).forEach { (p, icon) ->
                            NavigationBarItem(selected = page == p, onClick = { page = p }, icon = { Icon(icon, p) }, label = { Text(p) })
                        }
                    }
                }
            }
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (page) {
                    "Welcome" -> {
                        Text("One world. Many voices.", style = MaterialTheme.typography.headlineMedium)
                        Text("Share photos, shayari, quotes and positive moments with people around the world.")
                        Button(onClick = { page = "Register" }, modifier = Modifier.fillMaxWidth()) { Text("Create account") }
                        OutlinedButton(onClick = { page = "Login" }, modifier = Modifier.fillMaxWidth()) { Text("Login with email") }
                        Text("Prototype only: no real account is created.")
                    }
                    "Login", "Register" -> {
                        Text(if (page == "Login") "Login with email" else "Create account", style = MaterialTheme.typography.headlineSmall)
                        OutlinedTextField(email, { email = it }, label = { Text("Email address") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(password, { password = it }, label = { Text("Password — demo only") }, modifier = Modifier.fillMaxWidth())
                        if (page == "Register") OutlinedTextField(name, { name = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { page = "Feed" }, modifier = Modifier.fillMaxWidth()) { Text("Continue in demo mode") }
                        Text("Do not enter a real password. Firebase authentication is not connected.", color = MaterialTheme.colorScheme.error)
                        TextButton(onClick = { page = if (page == "Login") "Register" else "Login" }) { Text(if (page == "Login") "Create account instead" else "Already have an account?") }
                    }
                    "Feed" -> {
                        Text("Global feed", style = MaterialTheme.typography.headlineSmall)
                        Text("Demo data is stored only in this running session.", style = MaterialTheme.typography.bodySmall)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(posts.filter { it.privacy == "Public" || it.author == name }) { post ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("${post.author} · ${post.privacy}", style = MaterialTheme.typography.labelLarge)
                                        Text(post.text)
                                        Row {
                                            TextButton(onClick = { posts = posts.map { if (it.id == post.id) it.copy(liked = !it.liked, likes = (it.likes + if (it.liked) -1 else 1).coerceAtLeast(0)) else it }) { Icon(if (post.liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null); Text("${post.likes}") }
                                            TextButton(onClick = { commentId = post.id; page = "Comments" }) { Icon(Icons.Default.ChatBubbleOutline, null); Text("${post.comments.size}") }
                                            TextButton(onClick = { clipboard.setText(AnnotatedString(post.text)) }) { Icon(Icons.Default.ContentCopy, null); Text("Copy") }
                                            TextButton(onClick = { ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, post.text) }, "Share post")) }) { Icon(Icons.Default.Share, null); Text("Share") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    "Create" -> {
                        Text("Create a post", style = MaterialTheme.typography.headlineSmall)
                        OutlinedTextField(draft, { draft = it }, label = { Text("Quote, shayari or status…") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                        Text("Photo upload will be added with cloud storage.")
                        Row { listOf("Public", "Followers", "Only me").forEach { p -> Row(Modifier.weight(1f)) { RadioButton(privacy == p, { privacy = p }); Text(p, modifier = Modifier.padding(top = 12.dp)) } } }
                        Button(onClick = { if (draft.isNotBlank()) { posts = listOf(Post((posts.maxOfOrNull { it.id } ?: 0) + 1, name, draft.trim(), privacy)) + posts; draft = ""; page = "Feed" } }, modifier = Modifier.fillMaxWidth()) { Text("Publish demo post") }
                    }
                    "People" -> {
                        Text("Discover people", style = MaterialTheme.typography.headlineSmall)
                        listOf("Sunny", "Maya", "Aarav", "Sara", "World Connect").forEach { person ->
                            Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(12.dp)) {
                                Text(person, modifier = Modifier.weight(1f))
                                OutlinedButton(onClick = { follows = if (person in follows) follows - person else follows + person }) { Text(if (person in follows) "Following" else "Follow") }
                            } }
                        }
                    }
                    "Chat" -> {
                        Text("Messages", style = MaterialTheme.typography.headlineSmall)
                        Text("Demo chat only — not end-to-end encrypted.", color = MaterialTheme.colorScheme.error)
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(messages) { Card { Text(it, Modifier.padding(10.dp)) } } }
                        Row {
                            OutlinedTextField(message, { message = it }, label = { Text("Message") }, modifier = Modifier.weight(1f))
                            IconButton(onClick = { if (message.isNotBlank()) { messages = messages + "$name: $message"; message = "" } }) { Icon(Icons.Default.Send, "Send") }
                        }
                    }
                    "Comments" -> {
                        val post = posts.firstOrNull { it.id == commentId }
                        Text("Comments", style = MaterialTheme.typography.headlineSmall)
                        post?.let {
                            Text(it.text)
                            it.comments.forEach { c -> Text("• $c") }
                            OutlinedTextField(commentDraft, { commentDraft = it }, label = { Text("Write comment") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { if (commentDraft.isNotBlank()) { posts = posts.map { p -> if (p.id == commentId) p.copy(comments = p.comments + "$name: ${commentDraft.trim()}") else p }; commentDraft = "" } }) { Text("Add comment") }
                        }
                        TextButton(onClick = { page = "Feed" }) { Text("Back") }
                    }
                    "Profile" -> {
                        Text("Profile", style = MaterialTheme.typography.headlineSmall)
                        OutlinedTextField(name, { name = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(bio, { bio = it }, label = { Text("Bio") }, modifier = Modifier.fillMaxWidth())
                        Text("Email: ${email.ifBlank { "demo user" }}")
                        Text("Country: $country · Language: $language")
                        Text("Following: ${follows.size} · Your posts: ${posts.count { it.author == name }}")
                        Button(onClick = { page = "Settings" }) { Text("Settings & privacy") }
                    }
                    "Settings" -> {
                        Text("Settings & privacy", style = MaterialTheme.typography.headlineSmall)
                        var cOpen by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = cOpen, onExpandedChange = { cOpen = it }) {
                            OutlinedTextField(country, {}, readOnly = true, label = { Text("Country") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(cOpen) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = cOpen, onDismissRequest = { cOpen = false }) { countries.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { country = it; cOpen = false }) } }
                        }
                        var lOpen by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = lOpen, onExpandedChange = { lOpen = it }) {
                            OutlinedTextField(language, {}, readOnly = true, label = { Text("App language") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(lOpen) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = lOpen, onDismissRequest = { lOpen = false }) { languages.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { language = it; lOpen = false }) } }
                        }
                        Text("Privacy labels: Public / Followers / Only me")
                        Text("Privacy is not server-enforced in this prototype.", color = MaterialTheme.colorScheme.error)
                        OutlinedButton(onClick = { page = "Welcome"; email = ""; password = "" }, modifier = Modifier.fillMaxWidth()) { Text("Log out of demo") }
                    }
                }
            }
        }
    }
}
