# World Connect — Android MVP starter

This is a native Android **demo MVP starter**, with a GitHub Actions cloud build workflow. It includes screens for email-style login/register, profile, quote/status posts, public/followers/only-me visibility selection, likes, comments, copy/share, follow/unfollow, country/language selection, and a basic demo chat.

## Important limits
- This build is a local UI prototype. Accounts, posts, follows, comments, and messages are in-memory demo data and do not sync between devices.
- Do not enter a real password. Production email authentication, email verification/reset, cloud database, photo upload/download, and server-enforced privacy are not connected yet.
- The chat is standard demo chat, not end-to-end encrypted. Do not claim E2E encryption until a protocol is implemented and independently reviewed.
- Country/language pickers are UI preferences only; translation is not implemented.
- Public posts can be screenshotted or copied even if download controls are restricted.
- Before launch, implement Firebase Auth/Firestore/Storage, strict security rules, App Check, report/block/moderation, account deletion, privacy policy, and Play Console data-safety disclosures.

## Build from Android phone + GitHub
1. Extract the ZIP on your Android phone.
2. Create a GitHub repository called `world-connect-android`.
3. Upload all files from this folder while preserving paths, especially `.github/workflows/build-android.yml`. If folder upload is difficult on mobile, use GitHub Codespaces.
4. Open **Actions** → **Build World Connect APK** → **Run workflow** (or push to `main`).
5. Wait for a green successful run. Open the run and download artifact `world-connect-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from the browser/files app.

If the workflow fails, no APK should be assumed to exist; open the failed step and share its error.

## Play Store
The debug APK is for testing only. Public release requires a signed Android App Bundle (`.aab`), secure signing, privacy policy, screenshots, content rating, Data safety declarations, testing, and Play Console review.
